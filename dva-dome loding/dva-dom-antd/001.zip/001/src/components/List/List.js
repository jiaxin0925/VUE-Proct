import React from 'react';
import styles from './List.css';

const List=()=>{
  return (
    <div className={styles.normal}>
      Component: List
    </div>
  );
}

export default List;
