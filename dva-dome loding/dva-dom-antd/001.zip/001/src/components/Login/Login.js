import React from 'react';
import styles from './Login.css';

const Login=()=>{
  return (
    <div className={styles.normal}>
      Component: Login
    </div>
  );
}

export default Login;
