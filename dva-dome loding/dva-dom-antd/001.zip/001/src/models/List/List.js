
export default {
  namespace: 'List',
  state: {},
  reducers: {},
  effects: {},
  subscriptions: {
    setup(){
      console.log("seyup")
    }
  },
};
